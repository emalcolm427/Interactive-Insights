$(document).ready(function() {

	// init ScrollMagic
	var controller = new ScrollMagic.Controller();


	// wipes away all the slides
	var pinIntroSlide = new ScrollMagic.Scene({
		triggerElement: "#container1",
		triggerHook: 0
	})
	.setPin("#container1")
	.addTo(controller);

	var pinIntroSlide = new ScrollMagic.Scene({
		triggerElement: "#container2",
		triggerHook: 0
	})
	.setPin("#container2")
	.addTo(controller);


	var pinIntroSlide = new ScrollMagic.Scene({
		triggerElement: "#container3",
		triggerHook: 0
	})
	.setPin("#container3")
	.addTo(controller);

	var pinIntroSlide = new ScrollMagic.Scene({
		triggerElement: "#container4",
		triggerHook: 0
	})
	.setPin("#container4")
	.addTo(controller);

	var pinIntroSlide = new ScrollMagic.Scene({
		triggerElement: "#container5",
		triggerHook: 0
	})
	.setPin("#container5")
	.addTo(controller);

	var pinIntroSlide = new ScrollMagic.Scene({
		triggerElement: "#container6",
		triggerHook: 0
	})
	.setPin("#container6")
	.addTo(controller);

		var pinIntroSlide = new ScrollMagic.Scene({
		triggerElement: "#container7",
		triggerHook: 0
	})
	.setPin("#container7")
	.addTo(controller);

	var pinIntroSlide = new ScrollMagic.Scene({
		triggerElement: "#container8",
		triggerHook: 0
	})
	.setPin("#container8")
	.addTo(controller);

	// slide in the title
	TweenLite.from("#welcome1", 1.5, {x: 1000});
	TweenLite.from("#welcome2", 1.5, {x: -1000});

	// makes arrows float
	function elementFloat(elementItem) {
	  TweenMax.to(elementItem, 2, {
	    y: "-=15px",
	    yoyo:true,
	    repeat:-1,
	    ease: Power2.easeInOut
	  });
	}

	elementFloat(".arrow-container");

	// fade in the slide 2 opening message
	var fadeIn = new ScrollMagic.Scene({
		triggerElement: '#container2',
		duration: 550
	})
	.setClassToggle('.openingMessage','fade-in')
	.addTo(controller);

	// fade in the slide 3 opening message
	var fadeIn = new ScrollMagic.Scene({
		triggerElement: '#container3',
		duration: 550
	})
	.setClassToggle('.openingMessage','fade-in')
	.addTo(controller);

	// blocks appear one by one
	TweenMax.set('.block1');
	var tween = new TimelineMax()
		.to('.block1', 1, {opacity: "1"})
		.to('.block2', 1, {opacity: "1"})
		.to('.block3', 1, {opacity: "1"})
		.to('.block4', 1, {opacity: "1"})
		.to('.block5', 1, {opacity: "1"})
		.to('.block6', 1, {opacity: "1"})
		.to('#openingMessage1', 1, {opacity: "0"}
	);

	var scene = new ScrollMagic.Scene({triggerElement: '.block1'})
		.setTween(tween)
		.addTo(controller);	

	// slide 3 text fading in
	TweenMax.set('#slide3text1');
	var tween = new TimelineMax()
		//fades elements in
		.to('#slide3text1', 1, {opacity: "1"})
		.to('.whiteDivider1', 1, {opacity: "1"})
		.to('#slide3text2',1, {opacity: "1"})
		.to('.whiteDivider2',1, {opacity: "1"})
		.to('#slide3text3',1.3,{opacity: "1"})

		//simultaneously fades out elements on page
		.to(['#slide3text1','.whiteDivider1', '#slide3text2', '.whiteDivider2', '#slide3text3', '#openingMessage2'], 1, {opacity: "0"})

		//fades in chart1
		.to('#chart1container', 2, {opacity: "1"})
		.to('#commentaryContainer1', 1, {opacity: "1"})
		.to('#commentaryContainer2', 1, {opacity: "1"})
		.to('#buttonContainer1', 1, {opacity: "1"}
	);

	var scene = new ScrollMagic.Scene({triggerElement: '#slide3text1'})
		.setTween(tween)
		.addTo(controller);

	//at this point I think that I should have some sort of button to trigger 
	//movement


	// chart 1 stuff ***************************
	google.charts.load('current', {
  		packages: ['corechart', 'bar']
	});
	google.charts.setOnLoadCallback(drawStacked);

	function drawStacked() {
		var data = google.visualization.arrayToDataTable([
			['Position Class', 'Male', 'Female', ],
    			['40', 1408, 817],
			['41', 22960, 8325],	
			['42', 56415, 20573],
			['43', 24555, 17885],
			['44', 38083, 22457],
			['45', 15009, 12579],
			['46', 20691, 17200],
			['47', 18596, 13300],
			['48', 19909, 14628],
			['49', 24235, 11695],
  		 	['50', 28617, 11904],
    			['51', 30550, 9956],
    			['52', 23324, 8958],
    			['53', 13109, 5951],
    			['54', 14324, 6182],
    			['55', 11682, 4885],
    			['56', 11086, 4478],
    			['57', 7253, 2595],
    			['58', 6972, 2511],
    			['59', 4809, 1586],
    			['60', 5045, 1027],
    			['61', 1604, 433],
    			['62', 1353, 441],
    			['63', 766, 177],
    			['64', 710, 180],
    			['65', 485, 88],
    			['66', 258, 51],
    			['67', 127, 19],
    			['68', 137, 14],
    			['69', 112, 14],
    			['70', 78, 6],
    			['71', 34, 4],
    			['72', 30, 2],
    			['73', 24, 0],
    			['74', 18, 0],
    			['75', 2, 0],
    			['76', 4, 1],
    			['77', 4, 0],
    			['78', 1, 0],
    			['79', 3, 0],
    			['80', 0, 0],
    			['81', 1, 0],
    			['82', 0, 0],
    			['83', 1, 0]
		]);

  		var options = {
    			title: 'Gender Distribution by Position Class',
    			isStacked: true,
    			legend: 'none',
    			hAxis: {
      				title: 'Count',
      				viewWindow: {
        				min: 0,
       					max: 80000,
      				},
    			},
    			vAxis: {
      				title: 'Position Class'
    			},
    			series: {
      				0: {
        				color: '#DF6E00'
      				},
      				1: {
        				color: '#4D3D6A'
      				}
    			}
  		};
  		var chart = new google.visualization.BarChart(document.getElementById('chart1container'));
  		chart.draw(data, options);
	}
	
	//keeps track of which chart is being displayed
	var chartCounter = 0;
	
	$('#button1').click(function(){

		chartCounter++;
		
		var controller = new ScrollMagic.Controller();

	//chart2 stuffz 
	if (chartCounter == 1) {
		TweenMax.set('#chart1container');
		var tween = new TimelineMax()
			.to(['#chart1container', '#commentaryContainer1', '#commentaryContainer2'], 1, {opacity: "0"})
			.to('#chart1container', 0.1, {zIndex: 0}
		);

		var scene = new ScrollMagic.Scene()
			.setTween(tween)
			.addTo(controller);

		google.charts.load('current', {
  		packages: ['corechart', 'bar']
		});
		google.charts.setOnLoadCallback(drawStacked2);

		function drawStacked2() {
			var data = google.visualization.arrayToDataTable([
				['Position Class', 'Male', 'Female', ],
    				['60', 5045, 1027],
    				['61', 1604, 433],
    				['62', 1353, 441],
    				['63', 766, 177],
    				['64', 710, 180],
    				['65', 485, 88],
    				['66', 258, 51],
    				['67', 127, 19],
    				['68', 137, 14],
    				['69', 112, 14]
			]);

  			var options = {
    				title: 'Gender Distribution by Position Class',
    				isStacked: true,
    				legend: 'none',
    				hAxis: {
      					title: 'Count',
      					viewWindow: {
        					min: 0,
       						max: 2200,
      					},
    				},
    				vAxis: {
      					title: 'Position Class'
    				},
    				series: {
      					0: {
        					color: '#DF6E00'
      					},
      					1: {
        					color: '#4D3D6A'
      					}
    				}
  			};
  			var chart = new google.visualization.BarChart(document.getElementById('chart2container'));
  			chart.draw(data, options);
		}

		//fades in second chart and commentary
		TweenMax.set('#chart2container');
		var tween = new TimelineMax()
			.to('#chart2container', 1, {opacity: "1"})
			.to(['#buttonContainer2', '#commentaryContainer3'], 1, {opacity: "1"})
			.to('#commentaryContainer4', 1, {opacity: "1"}
		);

		var scene = new ScrollMagic.Scene()
			.setTween(tween)
			.addTo(controller);
	} //closing bracket for first if statement


	//chart3 stuff
	if (chartCounter == 2) {
		TweenMax.set('#chart2container');
		var tween = new TimelineMax()
			.to(['#chart2container', '#commentaryContainer3', '#commentaryContainer4'], 1, {opacity: "0"})
			.to('#chart2container', 0.1, {zIndex: 0}
		);

		var scene = new ScrollMagic.Scene()
			.setTween(tween)
			.addTo(controller);

		google.charts.load('current', {
  		packages: ['corechart', 'bar']
		});
		google.charts.setOnLoadCallback(drawStacked);

		function drawStacked() {
  			var data = google.visualization.arrayToDataTable([
    				['Position Class', 'Male', 'Female', ],
    				['70', 78, 6],
   				['71', 34, 4],
    				['72', 30, 2],
    				['73', 24, 0],
    				['74', 18, 0],
    				['75', 2, 0],
    				['76', 4, 1],
    				['77', 4, 0],
    				['78', 1, 0],
    				['79', 3, 0],
    				['80', 0, 0],
    				['81', 1, 0],
    				['82', 0, 0],
    				['83', 1, 0] 
  				]);

  		var options = {
    		title: 'Typical Gender Distribution by Position Class',
    		isStacked: true,
    		legend: 'none',
    		hAxis: {
      			title: 'Count',
      			viewWindow: {
       		 		min: 0,
        			max: 85
      			},
    		},
    		vAxis: {
      			title: 'Position Class'
    		},
    		series: {
      			0: {
        			color: '#DF6E00'
      			},
      			1: {
        			color: '#4D3D6A'
      			}
    		}
  		};
  		var chart = new google.visualization.BarChart(document.getElementById('chart3container'));
 		chart.draw(data, options);
	}

		//fades in third chart and commentary
		TweenMax.set('#chart3container');
		var tween = new TimelineMax()
			.to('#chart3container', 1, {opacity: "1"})
			.to('#commentaryContainer5', 1, {opacity: "1"})
			.to('#commentaryContainer6', 1, {opacity: "1"})
			.to('#button1', 1, {opacity: "0"}
		);

		var scene = new ScrollMagic.Scene()
			.setTween(tween)
			.addTo(controller);



	} //closing bracked for second if statement


	}); //closes out button1 activated code

	//variable to help with button animations
	var clickCounter = 0;

	$('#button3').click(function(){

		clickCounter++; 

		var controller = new ScrollMagic.Controller();

		if (clickCounter == 1) {
			TweenMax.set('#container5');
			var tween = new TimelineMax()
				.to('#slide5text1', 1, {opacity: "0"})
				.to(['#slide5block1','#slide5block1text','#slide5block2','#slide5block2num','#slide5block2text','#slide5block3','#slide5block3num','#slide5block3text','#openingMessage4'], 1, {opacity: "0"})
				.to(['#buttonContainer4','#slide5text2'], 1, {opacity: "1"})
				.to('#slide5text3', 1, {opacity: "1"})
				.to('#slide5text4', 1, {opacity: "1"}
			);

			var scene = new ScrollMagic.Scene()
				.setTween(tween)
				.addTo(controller);
		}

		if (clickCounter == 2) {
			TweenMax.set('#container5');
			var tween = new TimelineMax()
				.to(['#slide5text2','#slide5text3','#slide5text4'], 1, {opacity: "0"})
				.to('#tableContainer', 1, {opacity: "1"})
				.to('#slide5text5', 1, {opacity: "1"})
				.to('#slide5text6', 1, {opacity: "1"}
			);

			var scene = new ScrollMagic.Scene()
				.setTween(tween)
				.addTo(controller);

      google.charts.load('current', {'packages':['table']});
      google.charts.setOnLoadCallback(drawTable);

      function drawTable() {
        var data = new google.visualization.DataTable();
        data.addColumn('string', 'Position Code');
        data.addColumn('number', 'M Count');
        data.addColumn('number', 'F Count');
        data.addColumn('string', 'M Med. COMP1');
        data.addColumn('string', 'F Med. COMP1');
        data.addColumn('string', '% M Adv.');
        data.addColumn('string', '% F Total');
        data.addRows([
['510.652.420', 19049, 926,'$30,201.60', '$21,156.60', '29.95%', '11.82%'],
['510.240.350', 217, 834, '$38,000.04', '$38,000.04', '0.00%', '10.65%'],
['510.652.430',	2159, 693, '$19,463.80', '$17,085.00', '12.22%', '8.85%'],
['510.652.350',	10021, 322, '$32,365.32', 	 '$32,365.32', 	'0.00%',	'4.11%'],
['510.640.350',	1178,	275, '$32,834.70', 	 '$32,283.00', 	'1.68%',	'3.51%'],
['510.652.340',	3481,	245, '$39,062.88', 	 '$41,844.00', 	'-7.12%',	'3.13%'],
['510.704.350',	1872,	219, '$36,093.48', 	 '$36,312.00', 	'-0.61%',	'2.80%'],
['510.928.220',	705,	190, '$49,758.00', 	 '$42,823.50', 	'13.94%',	'2.43%'],
['510.240.220',	725,	183,'$51,122.64', 	 '$48,339.24', 	'5.44%',	'2.34%'],
['510.648.350',	1000,	178, '$35,700.00', 	 '$33,611.46', 	'5.85%',	'2.27%'],
['510.648.340',	1123,	171, '$45,421.92', 	 '$44,117.40', 	'2.87%',	'2.18%'],
['510.640.340',	1100,	164, '$45,201.00', 	 '$45,145.98', 	'0.12%',	'2.09%'],
['510.928.410',	1287,	161, '$30,749.94', 	 '$25,148.00', 	'18.22%',	'2.06%'],
['510.676.350',	975,	159, '$35,834.04', 	 '$32,352.00', 	'9.72%',	'2.03%'],
['510.704.340',	1513,	153, '$43,890.00', 	 '$44,004.00', 	'-0.26%',	'1.95%'],
['510.692.350',	1871,	140, '$26,630.88', 	 '$33,172.65', 	'-24.56%',	'1.79%'],
['510.240.320',	112,	134, '$72,000.00', 	 '$72,000.00', 	'0.00%',	'1.71%'],
['510.652.220',	1390,	131, '$51,891.92', 	 '$49,871.40', 	'3.89%',	'1.67%'],
['510.496.350',	1325,	131, '$36,612.24', 	 '$33,962.52', 	'7.24%',	'1.67%'],
['510.652.410',	1954,	120, '$29,289.00', 	 '$27,390.24', 	'6.48%',	'1.53%'],
['510.240.351',	319,	114, '$38,558.52 ',	 '$36,753.48', 	'4.68%',	'1.46%'],
['510.704.420',	893,	101, '$34,680.96', 	 '$32,352.00', 	'6.72%',	'1.29%'],
['510.668.350',	204,	100, '$36,510.84', 	 '$32,095.62', 	'12.09%',	'1.28%'],
['510.704.360',	759,	93, '$29,503.60', 	 '$27,999.96', 	'5.10%',	'1.19%'],
['510.928.354',	202,	88, '$30,654.00', 	 '$28,366.56', 	'7.46%',	'1.12%'],
['510.668.340',	167,	87, '$41,171.04', 	 '$44,000.04', 	'-6.87%',	'1.11%'],
['510.660.340',	1036,	85, '$47,217.00', 	 '$46,920.00', 	'0.63%',	'1.09%'],
['510.676.340',	180,	73, '$19,817.64', 	 '$16,911.48', 	'14.66%',	'0.93%'],
['510.688.350',	812,	70, '$38,000.04', 	 '$36,889.98', 	'2.92%',	'0.89%'],
['510.692.344',	645,	68, '$43,999.92', 	 '$44,479.86', 	'-1.09%',	'0.87%'],
['510.704.430',	316,	68, '$26,972.52', 	 '$25,414.98', 	'5.77%',	'0.87%'],
['510.928.351',	372,	65, '$39,987.00', 	 '$36,903.60', 	'7.71%',	'0.83%'],
['510.496.340',	876,	64, '$45,500.46', 	 '$44,528.76', 	'2.14%',	'0.82%'],
['510.240.340',	185,	64, '$49,670.04', 	 '$47,672.46', 	'4.02%',	'0.82%'],
['510.240.360',	58,	58, '$29,284.14', 	 '$23,667.78', 	'19.18%',	'0.74%'],
['510.668.360',	77,	56,	'$26,400.00',	 '$26,439.36', 	'-0.15%',	'0.72%'],
['510.652.360',	881,	53, '$32,867.00', 	 '$29,700.00', 	'9.64%',	'0.68%'],
['510.668.230',	71,	51,	'$47,499.96', 	 '$42,801.24', 	'9.89%',	'0.65%'],
['510.656.350',	493,	51, '$32,633.88', 	 '$28,188.24', 	'13.62%',	'0.65%'],
['510.696.350',	70,	50,	'$35,880.00', 	 '$29,129.04', 	'18.82%',	'0.64%'], 
['510.646.350',	304,	43, '$27,427.98', 	 '$31,999.92', 	'-16.67%',	'0.55%'],
['510.704.221',	618,	43, '$57,484.17', 	 '$55,303.56', 	'3.79%',	'0.55%'],
['510.660.350',	680,	41, '$37,100.04', 	 '$36,750.00', 	'0.94%',	'0.52%'],
['510.660.410',	943,	40, '$29,545.68', 	 '$25,540.44', 	'13.56%',	'0.51%'],
['510.684.220',	660,	40, '$55,763.40', 	 '$46,325.46', 	'16.92%',	'0.51%'],
['510.660.360',	576,	38, '$29,545.68', 	 '$29,545.68', 	'0.00%',	'0.49%'],
['510.415.340',	580,	37, '$45,221.04', 	 '$43,452.00', 	'3.91%',	'0.47%'],
['510.696.340',	96,	36,	'$46,275.00', 	 '$39,659.82', 	'14.30%',	'0.46%'],
['510.526.350',	2457,	34, '$31,865.64', 	 '$28,618.50', 	'10.19%',	'0.43%'],
['510.415.350',	438,	31, '$39,389.04', 	 '$36,330.00', 	'7.77%',	'0.40%'],
['510.640.220',	229,	30, '$60,159.96', 	 '$61,254.72', 	'-1.82%',	'0.38%'],
['510.715.350',	208,	30, '$37,617.24', 	 '$36,759.00', 	'2.28%',	'0.38%'],
['510.240.130',	144,	29, '$80,119.52', 	 '$62,499.96', 	'21.99%',	'0.37%'],
['510.652.330',	474,	28, '$43,907.76', 	 '$53,000.04', 	'-20.71%',	'0.36%'],
['510.692.224',	639,	26,	'$55,889.04', 	 '$56,344.98', 	'-0.82%',	'0.33%'],
['510.715.340',	327,	26,	'$50,351.16', 	 '$44,737.86', 	'11.15%',	'0.33%'],
['510.496.360',	309,	24, '$28,839.96', 	 '$30,197.34', 	'-4.71%',	'0.31%'],
['510.668.220',	59,	22,	'$58,372.20', 	 '$47,092.62', 	'19.32%',	'0.28%'],
['510.240.420',	18,	21,	'$32,925.96', 	 '$28,280.04', 	'14.11%',	'0.27%'],
['510.715.360',	53,	20,	'$24,996.00', 	 '$28,726.38', 	'-14.92%',	'0.26%'],
['510.415.220',	214,	18,	'$57,511.02', 	 '$66,938.34', 	'-16.39%',	'0.23%'],
['510.030.120',	321,	18,	'$77,925.00', 	 '$72,436.98', 	'7.04%',	'0.23%'],
['510.676.220',	101,	17,	'$58,722.00', 	 '$54,408.00', 	'7.35%',	'0.22%'],
['510.415.360',	116,	16,	'$27,745.98', 	 '$28,839.96', 	'-3.94%',	'0.20%'],
['510.496.220',	451,	14,	'$55,805.04', 	 '$64,960.02', 	'-16.41%',	'0.18%'],
['510.652.130',	204,	13,	'$77,348.76', 	 '$75,481.27', 	'2.41%',	'0.17%'],
['510.660.220',	333,	12,	'$58,100.04', 	 '$52,710.78', 	'9.28%',	'0.15%'],
['510.640.230',	148,	11, '$46,032.36', 	 '$45,000.00', 	'2.24%',	'0.14%'],
['510.240.430',	3,	11,	'$28,500.00', 	 '$27,264.96', 	'4.33%',	'0.14%'],
['510.526.340',	588,	11,	'$39,957.24', 	 '$35,700.00', 	'10.65%',	'0.14%'],
['510.380.351',	46,	11, '$32,733.54', 	 '$24,320.04', 	'25.70%',	'0.14%'],
['510.664.351',	105,	10, '$38,000.04', 	 '$43,951.98', 	'-15.66%',	'0.13%'],
['510.928.130',	42,	10, '$91,094.52', 	 '$93,830.02', 	'-3.00%',	'0.13%'],
['510.715.220',	184,	7, '$65,708.69', 	 '$58,803.12', 	'10.51%',	'0.09%'],
['510.240.410',	20,	6, '$32,878.02', 	 '$29,612.82', 	'9.93%',	'0.08%'],
['510.380.341',	18,	5, '$43,920.00', 	 '$44,476.80', 	'-1.27%',	'0.06%'],
['510.704.130',	143,	4, '$86,904.00', 	 '$117,500.00', 	'-35.21%',	'0.05%'],
['510.696.220',	37,	4, '$55,188.00', 	 '$55,057.02', 	'0.24%',	'0.05%'],
['510.415.130',	38,	3, '$73,979.40', 	 '$63,996.00', 	'13.49%',	'0.04%'],
['510.688.220',	33,	2, '$58,850.04', 	 '$71,062.02', 	'-20.75%',	'0.03%'],
['510.718.350',	0, 1, 'NA', 	 '$51,000.00', 	'0.00%',	'0.01%'],
['510.496.130',	49,	1, '$75,999.96', 	 '$80,412.60', 	'-5.81%',	'0.01%'],
['510.000.120',	4,	0, '$295,000.00', 	  'NA' 	,'0.00%'	,'0.00%'],
['510.010.120',	20,	0, '$124,184.50', 	  'NA' 	,'0.00%'	,'0.00%'],
['510.020.120',	53,	0, '$107,175.00', 	  'NA' 	,'0.00%'	,'0.00%'],
['510.691.350',	2,	0, '$36,771.06', 	  'NA' 	,'0.00%'	,'0.00%'],
['510.691.410',	251,	0, '$28,575.00', 	 'NA' 	,'0.00%'	,'0.00%'],
['510.718.340',	11,	0, '$70,226.16',	  'NA' 	,'0.00%'	,'0.00%']
]);

        var table = new google.visualization.Table(document.getElementById('tableContainer'));

        table.draw(data, {showRowNumber: true, width: '100%', height: '100%'});
      }


} //ending if bracket

	if (clickCounter == 3) {
		TweenMax.set('#container5');
		var tween = new TimelineMax()
			.to(['#slide5text5','#slide5text6'], 1, {opacity: "0"})
			.to('#slide5block4', 1, {opacity: "1"})
			.to('#slide5block5', 1, {opacity: "1"})
			.to('#slide5block6', 1, {opacity: "1"}
		);

		var scene = new ScrollMagic.Scene()
			.setTween(tween)
			.addTo(controller);
	}

	if (clickCounter == 4) {
		TweenMax.set('#container5');
		var tween = new TimelineMax()
			.to(['#slide5block4','#slide5block5','#slide5block6'], 1, {opacity: "0"})
			.to('#slide5text7', 1, {opacity: "1"})
			.to('#slide5text8', 1, {opacity: "1"}
		);

		var scene = new ScrollMagic.Scene()
			.setTween(tween)
			.addTo(controller);
	}

	if (clickCounter == 5) {
		TweenMax.set('#container5');
		var tween = new TimelineMax()
			.to(['#slide5text7','#slide5text8'], 1, {opacity:"0"})
			.to('#slide5text9', 1, {opacity:"1"}
		);

		var scene = new ScrollMagic.Scene()
			.setTween(tween)
			.addTo(controller);
	}




	}); //closes out button3 activated code

	var clickCounterButton5 = 0;

	$('#button5').click(function(){

		clickCounterButton5++;
		
		if (clickCounterButton5 == 1) {
			TweenMax.set('#container6');
			var tween = new TimelineMax()
				.to(['#slide6text3','#slide6text4','#buttonContainer5'], 1, {opacity: "0"})
				.to('#slide6text5', 1, {opacity: "1"})
				.to(['#slide6text6','#maleSquareContainer'], 1, {opacity: "1"})
				.to(['#slide6text7','#femaleSquareContainer'], 1, {opacity: "1"})
				.to('#slide6text8', 1, {opacity: "1"}
			);

			var scene = new ScrollMagic.Scene()
				.setTween(tween)
				.addTo(controller);
			}

	}); //closes out button5 activated code



//navbar scrolling

window.addEventListener('scroll', scrollFunction);
window.addEventListener('scroll', slide5fadein);
window.addEventListener('scroll', slide6fadein);
window.addEventListener('scroll', slide6fadeout);
window.addEventListener('scroll', svgFadeIn);
window.addEventListener('scroll', slide7fadein);

function scrollFunction() {
  const nav = document.querySelector('.arrow');
  if (this.scrollY <= 500) {
    document.getElementById("arrow").style.top = "0px";
  } else if (this.scrollY > 500 && this.scrollY <= 1700) {
    document.getElementById("arrow").style.top = "58px";
  } else if (this.scrollY > 1700 && this.scrollY <= 3200 ) {
	document.getElementById("arrow").style.top = "112px";
  } else if (this.scrollY > 3200 && this.scrollY <= 5300 ) {
	document.getElementById("arrow").style.top = "168px";
  } else if (this.scrollY > 5300 && this.scrollY <= 7470 ) {
	document.getElementById("arrow").style.top = "222px";
  } else if (this.scrollY > 7470 && this.scrollY <= 17470 ) {
	document.getElementById("arrow").style.top = "276px";
  } else {
	document.getElementById("arrow").style.top = "330px";
  }

} 

var alreadyPlayed = false;

function slide5fadein() {

	if (this.scrollY > 5300 && this.scrollY <= 6300 && !alreadyPlayed) {

		var controller = new ScrollMagic.Controller();
	
		TweenMax.set('#container5');
		var tween = new TimelineMax()
		.to('#openingMessage4', 1, {opacity: "1"})
		.to('#slide5text1', 1, {opacity: "1"})
		.to(['#slide5block1','#slide5block1text'], 1, {opacity: "1"})
		.to(['#slide5block2','#slide5block2num','#slide5block2text'], 1, {opacity: "1"})
		.to(['#slide5block3', '#slide5block3num', '#slide5block3text'], 1, {opacity: "1"})
		.to('#buttonContainer3', 1, {opacity: "1"}
		);

		var scene = new ScrollMagic.Scene()
			.setTween(tween)
			.addTo(controller);

		alreadyPlayed = true;
	}
}

var alreadyPlayed2 = false;

function slide6fadein() {

	if (this.scrollY > 7470  && !alreadyPlayed2) {

		var controller = new ScrollMagic.Controller();
	
		TweenMax.set('#container6');
		var tween = new TimelineMax()
			.to('#slide6text3', 1, {opacity: "1"})
			.to('#slide6text4', 1, {opacity: "1"})
			.to('#buttonContainer5', 1, {opacity: "1"}
		);

		var scene = new ScrollMagic.Scene()
			.setTween(tween)
			.addTo(controller);

		alreadyPlayed2 = true;
	}
}

var alreadyPlayed3 = false;

function slide6fadeout() {

	if (this.scrollY > 8300  && !alreadyPlayed3) {

		var controller = new ScrollMagic.Controller();
	
		TweenMax.set('#container6');
		var tween = new TimelineMax()
			.to(['#openingMessage5','#slide6text5','#slide6text6','#slide6text7','#maleSquareContainer','#femaleSquareContainer','#slide6text8'], 0.5, {opacity: "0"})
			.to(['#svgContainer','#slide6text1','#slide6text2'], 1, {opacity: "1"}
		);

		var scene = new ScrollMagic.Scene()
			.setTween(tween)
			.addTo(controller);

		alreadyPlayed3 = true;
	}
}

var alreadyPlayed4 = false;

function svgFadeIn() {

	if (this.scrollY > 8400  && !alreadyPlayed4) {

		var controller = new ScrollMagic.Controller();
	
		TweenMax.set('#container6');
		var tween = new TimelineMax()
			.to(['#svgContainer','#slide6text1','#slide6text2'], 1, {opacity: "1"}
		);

		var scene = new ScrollMagic.Scene()
			.setTween(tween)
			.addTo(controller);

		alreadyPlayed4 = true;
	}
}

var alreadyPlayed5 = false;

function slide7fadein() {

	if (this.scrollY > 18800  && !alreadyPlayed5) {

		var controller = new ScrollMagic.Controller();
	
		TweenMax.set('#container7');
		var tween = new TimelineMax()
			.to('#slide7text1', 1, {opacity: "1"})
			.to('#slide7text2', 1, {opacity: "1"})
			.to('#slide7text3', 1, {opacity: "1"})
			.to('#slide7text4', 1, {opacity: "1"}
		);

		var scene = new ScrollMagic.Scene()
			.setTween(tween)
			.addTo(controller);

		alreadyPlayed5 = true;
	}
}





});