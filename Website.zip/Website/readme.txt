README

***What is this repository for?

Contains all the files necessary to run a demo website for the data delivery/visualization platform: Interactive Insights from a local machine.

***How do I get set up?

Simply make sure all the files are in the same directory named "Website" and click on index.html. 
Depending on your default browser, the website will automatically be pulled up and loaded.

***How is this website set up?

It's a single view website, built with 7 "slides" that are equal size. Depending on each slide's content, there is sticky positioning. This sticky position comes from a JS library called ScrollMagic.
Animations are done primarily using the JS library Greensock, which complements ScrollMagic well. 
Most graphs are built with Google Charts (very straight forward syntax and great online documentation). 
One portion is built using R's shiny.

***Areas that are not yet implemented

Since this website serves as a prototype, I originally built it on a screen with a 1920 x 1080 resolution. 
Because of that, it will look a little funny on a differently sized screen. 
Some of the animation effects will have obvious flaws. 
Need to convert all the px meausrements in the css file with percentages. 
None of the PREV buttons work. Just didn't have time to go back and implement that part. 
The mechanism for the NEXT buttons is very simple. The content on the page is controlled by a counter. 
To get the PREV button working simply create functions that will handle the event and decrement the counter to show the most previous content. 
Some of the animations (fade-ins, effects, etc.) aren't quite polished. 
There isn't enough consistency with how graphs are built. 
One slide leverages Shiny whereas most of the other figures are made with google charts. 
The content on slide 6 was built with an svg generator, but is implemented as a png.
