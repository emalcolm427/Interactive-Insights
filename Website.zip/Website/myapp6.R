library(shiny)
library(ggplot2)
library(rsconnect)
library(readr)

Master <- read_csv("Master.csv")
Master <- subset(Master, GENDER == "M" | GENDER == "F") #remove observations without gender


ui <- fluidPage (
  titlePanel(""),
  sidebarLayout(
    sidebarPanel(
      
      tags$head(
        tags$style(type="text/css", "label.radio { display: inline-block; }", ".radio input[type=\"radio\"] { float: none; }"),
        tags$style(type="text/css", "select { max-height: 530px; }"),
        tags$style(type="text/css", "textarea { max-height: 530px; }"),
        tags$style(type="text/css", ".jslider { max-height: 530px; }"),
        tags$style(type='text/css', ".well { max-height: 530px; }"),
        tags$style(type='text/css', ".span4 { max-height: 530px; }")
      ),
      
      sliderInput(inputId = "pos_class_slider",
                  "Select Position Classes",
                  value = c(40,83),
                  min = 40,
                  max = 83),
      sliderInput(inputId = "emp_num",
                  "Select Employer Size",
                  value = c(0, 55000),
                  min = 0,
                  max = 55000),
      sliderInput(inputId = "age_num",
                  "Select Employee Ages",
                  value = c(16,80),
                  min = 16,
                  max = 80),
      radioButtons(inputId = "gender_selector",
                   label = "Select Genders",
                   choices = list("Male" = "M", "Female" = "F", "Both" = "Both"),
                   selected = "Both",
                   inline = TRUE),
      checkboxGroupInput(inputId = "job_stream_selector",
                         label = "Select Job Streams",
                         choices = list("Paraprofessional" = 4, "Professional" = 3, "Management" = 2, "Executive" = 1),
                         selected = c(1:4)) #  ,
      # selectInput(inputId = "job_family_selector",
      #             label = "Select Job Families",
      #             choices = list("Top Management" = 100, "Corporate Affairs" = 110, "Legal" = 115, "HR" = 120, "Communications" = 140, "Consulting" = 150, "Finance and Administration" = 200, "Finance" = 210, "Administration" = 220, "Information Technology" = 310, "IT Analytics & Design" = 320, "IT Deployment & Support" = 330, "Sales & Marketing" = 400, "Marketing" = 410, "Sales" = 420, "Contact Centre" = 430, "R&D" = 500, "Engineering" = 510, "Project Engineering" = 520, "Repair & Maintenance" = 550, "Manufacturing" = 600, "Supply & Logistics" = 610, "Quality" = 620, "Unknown" = 720, "Property/Real Estate Mgmt" = 800, "Retail" = 810),
      #             selected = 1,
      #             multiple = TRUE),
      # selectInput(inputId = "region_selector",
      #             label = "Select Region",
      #             choices = list ("East Midlands" = "East Midlands", "North East" = "North East", "Scotland" = "Scotland", "Wales" = "Wales", "East of England" = "East of England", "North West" = "North West", "South East" = "South East", "West Midlands" = "West Midlands", "London" = "London", "Northern Ireland" = "Northern Ireland", "South West" = "South West", "Yorkshire and The Humber" = "Yorkshire and The Humber"),
      #             selected = 1,
      #             multiple = TRUE)
    ),
    mainPanel(
      
      tabsetPanel(type = "tabs",
                  tabPanel("Position Class", textOutput("subset_num"), br(), plotOutput("pos_class_plot")),
                  tabPanel("Base Salary", plotOutput("comp1_plot"))
      )
      
    )
  )
)

server <- function(input, output) {
  #this beaut subsets the data based on the user's inputs
  #as of now I can't think of a more efficient manner to subset the data :(
  #because of that I stopped after job stream because job family would be too crazy to do with this bad method
  dat <- reactive({
    if(input$job_stream_selector[1] == "4" & length(input$job_stream_selector) == 1) {
      if(input$gender_selector == "Both") {
        subset(Master,
               `Job Stream` == 4
               & POS_CLASS >= input$pos_class_slider[1] & POS_CLASS <= (input$pos_class_slider[2] + 1)
               & ORGDATA_NUM_EMP >= input$emp_num[1] & ORGDATA_NUM_EMP <= input$emp_num[2] 
               & AGE_NUM >= input$age_num[1] & AGE_NUM <= input$age_num[2]
        )
      } else if (input$gender_selector == "M") {
        subset(Master,
               `Job Stream` == 4
               & GENDER == "M"
               & POS_CLASS >= input$pos_class_slider[1] & POS_CLASS <= (input$pos_class_slider[2] + 1)
               & ORGDATA_NUM_EMP >= input$emp_num[1] & ORGDATA_NUM_EMP <= input$emp_num[2] 
               & AGE_NUM >= input$age_num[1] & AGE_NUM <= input$age_num[2]
        )
      } else if (input$gender_selector == "F") {
        subset(Master,
               `Job Stream` == 4
               & GENDER == "F"
               & POS_CLASS >= input$pos_class_slider[1] & POS_CLASS <= (input$pos_class_slider[2] + 1)
               & ORGDATA_NUM_EMP >= input$emp_num[1] & ORGDATA_NUM_EMP <= input$emp_num[2] 
               & AGE_NUM >= input$age_num[1] & AGE_NUM <= input$age_num[2]
        )
      } else {
        subset(Master,
               `Job Stream` == 4
               & POS_CLASS >= input$pos_class_slider[1] & POS_CLASS <= (input$pos_class_slider[2] + 1)
               & ORGDATA_NUM_EMP >= input$emp_num[1] & ORGDATA_NUM_EMP <= input$emp_num[2] 
               & AGE_NUM >= input$age_num[1] & AGE_NUM <= input$age_num[2]
        )
      }
    } 
    else if (input$job_stream_selector == "3" & length(input$job_stream_selector) == 1) {
      if(input$gender_selector == "Both") {
        subset(Master,
               `Job Stream` == 3
               & POS_CLASS >= input$pos_class_slider[1] & POS_CLASS <= (input$pos_class_slider[2] + 1)
               & ORGDATA_NUM_EMP >= input$emp_num[1] & ORGDATA_NUM_EMP <= input$emp_num[2]
               & AGE_NUM >= input$age_num[1] & AGE_NUM <= input$age_num[2]
        )
      } else if (input$gender_selector == "M") {
        subset(Master,
               `Job Stream` == 3
               & GENDER == "M"
               & POS_CLASS >= input$pos_class_slider[1] & POS_CLASS <= (input$pos_class_slider[2] + 1)
               & ORGDATA_NUM_EMP >= input$emp_num[1] & ORGDATA_NUM_EMP <= input$emp_num[2]
               & AGE_NUM >= input$age_num[1] & AGE_NUM <= input$age_num[2]
        )
      } else if (input$gender_selector == "F") {
        subset(Master,
               `Job Stream` == 3
               & GENDER == "F"
               & POS_CLASS >= input$pos_class_slider[1] & POS_CLASS <= (input$pos_class_slider[2] + 1)
               & ORGDATA_NUM_EMP >= input$emp_num[1] & ORGDATA_NUM_EMP <= input$emp_num[2]
               & AGE_NUM >= input$age_num[1] & AGE_NUM <= input$age_num[2]
        )
      } else {
        subset(Master,
               `Job Stream` == 3
               & POS_CLASS >= input$pos_class_slider[1] & POS_CLASS <= (input$pos_class_slider[2] + 1)
               & ORGDATA_NUM_EMP >= input$emp_num[1] & ORGDATA_NUM_EMP <= input$emp_num[2]
               & AGE_NUM >= input$age_num[1] & AGE_NUM <= input$age_num[2]
        )
      }
    } else if (input$job_stream_selector == "2" & length(input$job_stream_selector) == 1) {
      if(input$gender_selector == "Both") {
        subset(Master,
               `Job Stream` == 2
               & POS_CLASS >= input$pos_class_slider[1] & POS_CLASS <= (input$pos_class_slider[2] + 1)
               & ORGDATA_NUM_EMP >= input$emp_num[1] & ORGDATA_NUM_EMP <= input$emp_num[2]
               & AGE_NUM >= input$age_num[1] & AGE_NUM <= input$age_num[2]
        )
      } else if (input$gender_selector == "M") {
        subset(Master,
               `Job Stream` == 2
               & GENDER == "M"
               & POS_CLASS >= input$pos_class_slider[1] & POS_CLASS <= (input$pos_class_slider[2] + 1)
               & ORGDATA_NUM_EMP >= input$emp_num[1] & ORGDATA_NUM_EMP <= input$emp_num[2]
               & AGE_NUM >= input$age_num[1] & AGE_NUM <= input$age_num[2]
        )
      } else if (input$gender_selector == "F") {
        subset(Master,
               `Job Stream` == 2
               & GENDER == "F"
               & POS_CLASS >= input$pos_class_slider[1] & POS_CLASS <= (input$pos_class_slider[2] + 1)
               & ORGDATA_NUM_EMP >= input$emp_num[1] & ORGDATA_NUM_EMP <= input$emp_num[2]
               & AGE_NUM >= input$age_num[1] & AGE_NUM <= input$age_num[2]
        )
      } else {
        subset(Master,
               `Job Stream` == 2
               & POS_CLASS >= input$pos_class_slider[1] & POS_CLASS <= (input$pos_class_slider[2] + 1)
               & ORGDATA_NUM_EMP >= input$emp_num[1] & ORGDATA_NUM_EMP <= input$emp_num[2]
               & AGE_NUM >= input$age_num[1] & AGE_NUM <= input$age_num[2]
        )
      }
    } else if (input$job_stream_selector == "1" & length(input$job_stream_selector) == 1) {
      if(input$gender_selector == "Both") {
        subset(Master,
               `Job Stream` == 1
               & POS_CLASS >= input$pos_class_slider[1] & POS_CLASS <= (input$pos_class_slider[2] + 1)
               & ORGDATA_NUM_EMP >= input$emp_num[1] & ORGDATA_NUM_EMP <= input$emp_num[2]
               & AGE_NUM >= input$age_num[1] & AGE_NUM <= input$age_num[2]
        )
      } else if (input$gender_selector == "M") {
        subset(Master,
               `Job Stream` == 1
               & GENDER == "M"
               & POS_CLASS >= input$pos_class_slider[1] & POS_CLASS <= (input$pos_class_slider[2] + 1)
               & ORGDATA_NUM_EMP >= input$emp_num[1] & ORGDATA_NUM_EMP <= input$emp_num[2]
               & AGE_NUM >= input$age_num[1] & AGE_NUM <= input$age_num[2]
        )
      } else if (input$gender_selector == "F") {
        subset(Master,
               `Job Stream` == 1
               & GENDER == "F"
               & POS_CLASS >= input$pos_class_slider[1] & POS_CLASS <= (input$pos_class_slider[2] + 1)
               & ORGDATA_NUM_EMP >= input$emp_num[1] & ORGDATA_NUM_EMP <= input$emp_num[2]
               & AGE_NUM >= input$age_num[1] & AGE_NUM <= input$age_num[2]
        )
      } else {
        subset(Master,
               `Job Stream` == 1
               & POS_CLASS >= input$pos_class_slider[1] & POS_CLASS <= (input$pos_class_slider[2] + 1)
               & ORGDATA_NUM_EMP >= input$emp_num[1] & ORGDATA_NUM_EMP <= input$emp_num[2]
               & AGE_NUM >= input$age_num[1] & AGE_NUM <= input$age_num[2]
        )
      }
    } else if (input$job_stream_selector[1] == "4" & input$job_stream_selector[2] == "3" & length(input$job_stream_selector) == 2) {
      if(input$gender_selector == "Both") {
        subset(Master,
               (`Job Stream` == 4
               | `Job Stream` == 3)
               & POS_CLASS >= input$pos_class_slider[1] & POS_CLASS <= (input$pos_class_slider[2] + 1)
               & ORGDATA_NUM_EMP >= input$emp_num[1] & ORGDATA_NUM_EMP <= input$emp_num[2]
               & AGE_NUM >= input$age_num[1] & AGE_NUM <= input$age_num[2]
        )
      } else if (input$gender_selector == "M") {
        subset(Master,
               (`Job Stream` == 4
                | `Job Stream` == 3)
               & GENDER == "M"
               & POS_CLASS >= input$pos_class_slider[1] & POS_CLASS <= (input$pos_class_slider[2] + 1)
               & ORGDATA_NUM_EMP >= input$emp_num[1] & ORGDATA_NUM_EMP <= input$emp_num[2]
               & AGE_NUM >= input$age_num[1] & AGE_NUM <= input$age_num[2]
        )
      } else if (input$gender_selector == "F") {
        subset(Master,
               (`Job Stream` == 4
                | `Job Stream` == 3)
               & GENDER == "F"
               & POS_CLASS >= input$pos_class_slider[1] & POS_CLASS <= (input$pos_class_slider[2] + 1)
               & ORGDATA_NUM_EMP >= input$emp_num[1] & ORGDATA_NUM_EMP <= input$emp_num[2]
               & AGE_NUM >= input$age_num[1] & AGE_NUM <= input$age_num[2]
        )
      } else {
        subset(Master,
               (`Job Stream` == 4
                | `Job Stream` == 3)
               & POS_CLASS >= input$pos_class_slider[1] & POS_CLASS <= (input$pos_class_slider[2] + 1)
               & ORGDATA_NUM_EMP >= input$emp_num[1] & ORGDATA_NUM_EMP <= input$emp_num[2]
               & AGE_NUM >= input$age_num[1] & AGE_NUM <= input$age_num[2]
        )
      }
    } else if (input$job_stream_selector[1] == "4" & input$job_stream_selector[2] == "2" & length(input$job_stream_selector) == 2) {
      if(input$gender_selector == "Both") {
        subset(Master,
               (`Job Stream` == 4
                | `Job Stream` == 2)
               & POS_CLASS >= input$pos_class_slider[1] & POS_CLASS <= (input$pos_class_slider[2] + 1)
               & ORGDATA_NUM_EMP >= input$emp_num[1] & ORGDATA_NUM_EMP <= input$emp_num[2]
               & AGE_NUM >= input$age_num[1] & AGE_NUM <= input$age_num[2]
        )
      } else if (input$gender_selector == "M") {
        subset(Master,
               (`Job Stream` == 4
                | `Job Stream` == 2)
               & GENDER == "M"
               & POS_CLASS >= input$pos_class_slider[1] & POS_CLASS <= (input$pos_class_slider[2] + 1)
               & ORGDATA_NUM_EMP >= input$emp_num[1] & ORGDATA_NUM_EMP <= input$emp_num[2]
               & AGE_NUM >= input$age_num[1] & AGE_NUM <= input$age_num[2]
        )
      } else if (input$gender_selector == "F") {
        subset(Master,
               (`Job Stream` == 4
                | `Job Stream` == 2)
               & GENDER == "F"
               & POS_CLASS >= input$pos_class_slider[1] & POS_CLASS <= (input$pos_class_slider[2] + 1)
               & ORGDATA_NUM_EMP >= input$emp_num[1] & ORGDATA_NUM_EMP <= input$emp_num[2]
               & AGE_NUM >= input$age_num[1] & AGE_NUM <= input$age_num[2]
        )
      } else {
        subset(Master,
               (`Job Stream` == 4
                | `Job Stream` == 2)
               & POS_CLASS >= input$pos_class_slider[1] & POS_CLASS <= (input$pos_class_slider[2] + 1)
               & ORGDATA_NUM_EMP >= input$emp_num[1] & ORGDATA_NUM_EMP <= input$emp_num[2]
               & AGE_NUM >= input$age_num[1] & AGE_NUM <= input$age_num[2]
        )
      }
    } else if (input$job_stream_selector[1] == "4" & input$job_stream_selector[2] == "1" & length(input$job_stream_selector) == 2) {
      if(input$gender_selector == "Both") {
        subset(Master,
               (`Job Stream` == 4
                | `Job Stream` == 1)
               & POS_CLASS >= input$pos_class_slider[1] & POS_CLASS <= (input$pos_class_slider[2] + 1)
               & ORGDATA_NUM_EMP >= input$emp_num[1] & ORGDATA_NUM_EMP <= input$emp_num[2]
               & AGE_NUM >= input$age_num[1] & AGE_NUM <= input$age_num[2]
        )
      } else if (input$gender_selector == "M") {
        subset(Master,
               (`Job Stream` == 4
                | `Job Stream` == 1)
               & GENDER == "M"
               & POS_CLASS >= input$pos_class_slider[1] & POS_CLASS <= (input$pos_class_slider[2] + 1)
               & ORGDATA_NUM_EMP >= input$emp_num[1] & ORGDATA_NUM_EMP <= input$emp_num[2]
               & AGE_NUM >= input$age_num[1] & AGE_NUM <= input$age_num[2]
        )
      } else if (input$gender_selector == "F") {
        subset(Master,
               (`Job Stream` == 4
                | `Job Stream` == 1)
               & GENDER == "F"
               & POS_CLASS >= input$pos_class_slider[1] & POS_CLASS <= (input$pos_class_slider[2] + 1)
               & ORGDATA_NUM_EMP >= input$emp_num[1] & ORGDATA_NUM_EMP <= input$emp_num[2]
               & AGE_NUM >= input$age_num[1] & AGE_NUM <= input$age_num[2]
        )
      } else {
        subset(Master,
               (`Job Stream` == 4
                | `Job Stream` == 1)
               & POS_CLASS >= input$pos_class_slider[1] & POS_CLASS <= (input$pos_class_slider[2] + 1)
               & ORGDATA_NUM_EMP >= input$emp_num[1] & ORGDATA_NUM_EMP <= input$emp_num[2]
               & AGE_NUM >= input$age_num[1] & AGE_NUM <= input$age_num[2]
        )
      }
    } else if (input$job_stream_selector[1] == "3" & input$job_stream_selector[2] == "2" & length(input$job_stream_selector) == 2) {
      if(input$gender_selector == "Both") {
        subset(Master,
               (`Job Stream` == 3
                | `Job Stream` == 2)
               & POS_CLASS >= input$pos_class_slider[1] & POS_CLASS <= (input$pos_class_slider[2] + 1)
               & ORGDATA_NUM_EMP >= input$emp_num[1] & ORGDATA_NUM_EMP <= input$emp_num[2]
               & AGE_NUM >= input$age_num[1] & AGE_NUM <= input$age_num[2]
        )
      } else if (input$gender_selector == "M") {
        subset(Master,
               (`Job Stream` == 3
                | `Job Stream` == 2)
               & GENDER == "M"
               & POS_CLASS >= input$pos_class_slider[1] & POS_CLASS <= (input$pos_class_slider[2] + 1)
               & ORGDATA_NUM_EMP >= input$emp_num[1] & ORGDATA_NUM_EMP <= input$emp_num[2]
               & AGE_NUM >= input$age_num[1] & AGE_NUM <= input$age_num[2]
        )
      } else if (input$gender_selector == "F") {
        subset(Master,
               (`Job Stream` == 3
                | `Job Stream` == 2)
               & GENDER == "F"
               & POS_CLASS >= input$pos_class_slider[1] & POS_CLASS <= (input$pos_class_slider[2] + 1)
               & ORGDATA_NUM_EMP >= input$emp_num[1] & ORGDATA_NUM_EMP <= input$emp_num[2]
               & AGE_NUM >= input$age_num[1] & AGE_NUM <= input$age_num[2]
        )
      } else {
        subset(Master,
               (`Job Stream` == 3
                | `Job Stream` == 2)
               & POS_CLASS >= input$pos_class_slider[1] & POS_CLASS <= (input$pos_class_slider[2] + 1)
               & ORGDATA_NUM_EMP >= input$emp_num[1] & ORGDATA_NUM_EMP <= input$emp_num[2]
               & AGE_NUM >= input$age_num[1] & AGE_NUM <= input$age_num[2]
        )
      }
    } else if (input$job_stream_selector[1] == "3" & input$job_stream_selector[2] == "1" & length(input$job_stream_selector) == 2) {
      if(input$gender_selector == "Both") {
        subset(Master,
               (`Job Stream` == 1
                | `Job Stream` == 3)
               & POS_CLASS >= input$pos_class_slider[1] & POS_CLASS <= (input$pos_class_slider[2] + 1)
               & ORGDATA_NUM_EMP >= input$emp_num[1] & ORGDATA_NUM_EMP <= input$emp_num[2]
               & AGE_NUM >= input$age_num[1] & AGE_NUM <= input$age_num[2]
        )
      } else if (input$gender_selector == "M") {
        subset(Master,
               (`Job Stream` == 1
                | `Job Stream` == 3)
               & GENDER == "M"
               & POS_CLASS >= input$pos_class_slider[1] & POS_CLASS <= (input$pos_class_slider[2] + 1)
               & ORGDATA_NUM_EMP >= input$emp_num[1] & ORGDATA_NUM_EMP <= input$emp_num[2]
               & AGE_NUM >= input$age_num[1] & AGE_NUM <= input$age_num[2]
        )
      } else if (input$gender_selector == "F") {
        subset(Master,
               (`Job Stream` == 1
                | `Job Stream` == 3)
               & GENDER == "F"
               & POS_CLASS >= input$pos_class_slider[1] & POS_CLASS <= (input$pos_class_slider[2] + 1)
               & ORGDATA_NUM_EMP >= input$emp_num[1] & ORGDATA_NUM_EMP <= input$emp_num[2]
               & AGE_NUM >= input$age_num[1] & AGE_NUM <= input$age_num[2]
        )
      } else {
        subset(Master,
               (`Job Stream` == 1
                | `Job Stream` == 3)
               & POS_CLASS >= input$pos_class_slider[1] & POS_CLASS <= (input$pos_class_slider[2] + 1)
               & ORGDATA_NUM_EMP >= input$emp_num[1] & ORGDATA_NUM_EMP <= input$emp_num[2]
               & AGE_NUM >= input$age_num[1] & AGE_NUM <= input$age_num[2]
        )
      }
    } else if (input$job_stream_selector[1] == "2" & input$job_stream_selector[2] == "1" & length(input$job_stream_selector) == 2) {
      if(input$gender_selector == "Both") {
        subset(Master,
               (`Job Stream` == 2
                | `Job Stream` == 1)
               & POS_CLASS >= input$pos_class_slider[1] & POS_CLASS <= (input$pos_class_slider[2] + 1)
               & ORGDATA_NUM_EMP >= input$emp_num[1] & ORGDATA_NUM_EMP <= input$emp_num[2]
               & AGE_NUM >= input$age_num[1] & AGE_NUM <= input$age_num[2]
        )
      } else if (input$gender_selector == "M") {
        subset(Master,
               (`Job Stream` == 2
                | `Job Stream` == 1)
               & GENDER == "M"
               & POS_CLASS >= input$pos_class_slider[1] & POS_CLASS <= (input$pos_class_slider[2] + 1)
               & ORGDATA_NUM_EMP >= input$emp_num[1] & ORGDATA_NUM_EMP <= input$emp_num[2]
               & AGE_NUM >= input$age_num[1] & AGE_NUM <= input$age_num[2]
        )
      } else if (input$gender_selector == "F") {
        subset(Master,
               (`Job Stream` == 2
                | `Job Stream` == 1)
               & GENDER == "F"
               & POS_CLASS >= input$pos_class_slider[1] & POS_CLASS <= (input$pos_class_slider[2] + 1)
               & ORGDATA_NUM_EMP >= input$emp_num[1] & ORGDATA_NUM_EMP <= input$emp_num[2]
               & AGE_NUM >= input$age_num[1] & AGE_NUM <= input$age_num[2]
        )
      } else {
        subset(Master,
               (`Job Stream` == 2
                | `Job Stream` == 1)
               & POS_CLASS >= input$pos_class_slider[1] & POS_CLASS <= (input$pos_class_slider[2] + 1)
               & ORGDATA_NUM_EMP >= input$emp_num[1] & ORGDATA_NUM_EMP <= input$emp_num[2]
               & AGE_NUM >= input$age_num[1] & AGE_NUM <= input$age_num[2]
        )
      }
    }  else if (input$job_stream_selector[1] == "4" & input$job_stream_selector[2] == "3" & input$job_stream_selector[3] == "2" & length(input$job_stream_selector) == 3) {
      if(input$gender_selector == "Both") {
        subset(Master,
               (`Job Stream` == 4
                | `Job Stream` == 3
                | `Job Stream` == 2)
               & POS_CLASS >= input$pos_class_slider[1] & POS_CLASS <= (input$pos_class_slider[2] + 1)
               & ORGDATA_NUM_EMP >= input$emp_num[1] & ORGDATA_NUM_EMP <= input$emp_num[2]
               & AGE_NUM >= input$age_num[1] & AGE_NUM <= input$age_num[2]
        )
      } else if (input$gender_selector == "M") {
        subset(Master,
               (`Job Stream` == 4
                | `Job Stream` == 3
                | `Job Stream` == 2)
               & GENDER == "M"
               & POS_CLASS >= input$pos_class_slider[1] & POS_CLASS <= (input$pos_class_slider[2] + 1)
               & ORGDATA_NUM_EMP >= input$emp_num[1] & ORGDATA_NUM_EMP <= input$emp_num[2]
               & AGE_NUM >= input$age_num[1] & AGE_NUM <= input$age_num[2]
        )
      } else if (input$gender_selector == "F") {
        subset(Master,
               (`Job Stream` == 4
                | `Job Stream` == 3
                | `Job Stream` == 2)
               & GENDER == "F"
               & POS_CLASS >= input$pos_class_slider[1] & POS_CLASS <= (input$pos_class_slider[2] + 1)
               & ORGDATA_NUM_EMP >= input$emp_num[1] & ORGDATA_NUM_EMP <= input$emp_num[2]
               & AGE_NUM >= input$age_num[1] & AGE_NUM <= input$age_num[2]
        )
      } else {
        subset(Master,
               (`Job Stream` == 4
                | `Job Stream` == 3
                | `Job Stream` == 2)
               & POS_CLASS >= input$pos_class_slider[1] & POS_CLASS <= (input$pos_class_slider[2] + 1)
               & ORGDATA_NUM_EMP >= input$emp_num[1] & ORGDATA_NUM_EMP <= input$emp_num[2]
               & AGE_NUM >= input$age_num[1] & AGE_NUM <= input$age_num[2]
        )
      }
    }  else if (input$job_stream_selector[1] == "4" & input$job_stream_selector[2] == "3" & input$job_stream_selector[3] == "1" & length(input$job_stream_selector) == 3) {
      if(input$gender_selector == "Both") {
        subset(Master,
               (`Job Stream` == 4
                | `Job Stream` == 3
                | `Job Stream` == 1)
               & POS_CLASS >= input$pos_class_slider[1] & POS_CLASS <= (input$pos_class_slider[2] + 1)
               & ORGDATA_NUM_EMP >= input$emp_num[1] & ORGDATA_NUM_EMP <= input$emp_num[2]
               & AGE_NUM >= input$age_num[1] & AGE_NUM <= input$age_num[2]
        )
      } else if (input$gender_selector == "M") {
        subset(Master,
               (`Job Stream` == 4
                | `Job Stream` == 3
                | `Job Stream` == 1)
               & GENDER == "M"
               & POS_CLASS >= input$pos_class_slider[1] & POS_CLASS <= (input$pos_class_slider[2] + 1)
               & ORGDATA_NUM_EMP >= input$emp_num[1] & ORGDATA_NUM_EMP <= input$emp_num[2]
               & AGE_NUM >= input$age_num[1] & AGE_NUM <= input$age_num[2]
        )
      } else if (input$gender_selector == "F") {
        subset(Master,
               (`Job Stream` == 4
                | `Job Stream` == 3
                | `Job Stream` == 1)
               & GENDER == "F"
               & POS_CLASS >= input$pos_class_slider[1] & POS_CLASS <= (input$pos_class_slider[2] + 1)
               & ORGDATA_NUM_EMP >= input$emp_num[1] & ORGDATA_NUM_EMP <= input$emp_num[2]
               & AGE_NUM >= input$age_num[1] & AGE_NUM <= input$age_num[2]
        )
      } else {
        subset(Master,
               (`Job Stream` == 4
                | `Job Stream` == 3
                | `Job Stream` == 1)
               & POS_CLASS >= input$pos_class_slider[1] & POS_CLASS <= (input$pos_class_slider[2] + 1)
               & ORGDATA_NUM_EMP >= input$emp_num[1] & ORGDATA_NUM_EMP <= input$emp_num[2]
               & AGE_NUM >= input$age_num[1] & AGE_NUM <= input$age_num[2]
        )
      }
    }  else if (input$job_stream_selector[1] == "4" & input$job_stream_selector[2] == "2" & input$job_stream_selector[3] == "1" & length(input$job_stream_selector) == 3) {
      if(input$gender_selector == "Both") {
        subset(Master,
               (`Job Stream` == 4
                | `Job Stream` == 1
                | `Job Stream` == 2)
               & POS_CLASS >= input$pos_class_slider[1] & POS_CLASS <= (input$pos_class_slider[2] + 1)
               & ORGDATA_NUM_EMP >= input$emp_num[1] & ORGDATA_NUM_EMP <= input$emp_num[2]
               & AGE_NUM >= input$age_num[1] & AGE_NUM <= input$age_num[2]
        )
      } else if (input$gender_selector == "M") {
        subset(Master,
               (`Job Stream` == 4
                | `Job Stream` == 1
                | `Job Stream` == 2)
               & GENDER == "M"
               & POS_CLASS >= input$pos_class_slider[1] & POS_CLASS <= (input$pos_class_slider[2] + 1)
               & ORGDATA_NUM_EMP >= input$emp_num[1] & ORGDATA_NUM_EMP <= input$emp_num[2]
               & AGE_NUM >= input$age_num[1] & AGE_NUM <= input$age_num[2]
        )
      } else if (input$gender_selector == "F") {
        subset(Master,
               (`Job Stream` == 4
                | `Job Stream` == 1
                | `Job Stream` == 2)
               & GENDER == "F"
               & POS_CLASS >= input$pos_class_slider[1] & POS_CLASS <= (input$pos_class_slider[2] + 1)
               & ORGDATA_NUM_EMP >= input$emp_num[1] & ORGDATA_NUM_EMP <= input$emp_num[2]
               & AGE_NUM >= input$age_num[1] & AGE_NUM <= input$age_num[2]
        )
      } else {
        subset(Master,
               (`Job Stream` == 4
                | `Job Stream` == 1
                | `Job Stream` == 2)
               & POS_CLASS >= input$pos_class_slider[1] & POS_CLASS <= (input$pos_class_slider[2] + 1)
               & ORGDATA_NUM_EMP >= input$emp_num[1] & ORGDATA_NUM_EMP <= input$emp_num[2]
               & AGE_NUM >= input$age_num[1] & AGE_NUM <= input$age_num[2]
        )
      }
    }  else if (input$job_stream_selector[1] == "3" & input$job_stream_selector[2] == "2" & input$job_stream_selector[3] == "1" & length(input$job_stream_selector) == 3) {
      if(input$gender_selector == "Both") {
        subset(Master,
               (`Job Stream` == 1
                | `Job Stream` == 3
                | `Job Stream` == 2)
               & POS_CLASS >= input$pos_class_slider[1] & POS_CLASS <= (input$pos_class_slider[2] + 1)
               & ORGDATA_NUM_EMP >= input$emp_num[1] & ORGDATA_NUM_EMP <= input$emp_num[2]
               & AGE_NUM >= input$age_num[1] & AGE_NUM <= input$age_num[2]
        )
      } else if (input$gender_selector == "M") {
        subset(Master,
               (`Job Stream` == 1
                | `Job Stream` == 3
                | `Job Stream` == 2)
               & GENDER == "M"
               & POS_CLASS >= input$pos_class_slider[1] & POS_CLASS <= (input$pos_class_slider[2] + 1)
               & ORGDATA_NUM_EMP >= input$emp_num[1] & ORGDATA_NUM_EMP <= input$emp_num[2]
               & AGE_NUM >= input$age_num[1] & AGE_NUM <= input$age_num[2]
        )
      } else if (input$gender_selector == "F") {
        subset(Master,
               (`Job Stream` == 1
                | `Job Stream` == 3
                | `Job Stream` == 2)
               & GENDER == "F"
               & POS_CLASS >= input$pos_class_slider[1] & POS_CLASS <= (input$pos_class_slider[2] + 1)
               & ORGDATA_NUM_EMP >= input$emp_num[1] & ORGDATA_NUM_EMP <= input$emp_num[2]
               & AGE_NUM >= input$age_num[1] & AGE_NUM <= input$age_num[2]
        )
      } else {
        subset(Master,
               (`Job Stream` == 1
                | `Job Stream` == 3
                | `Job Stream` == 2)
               & POS_CLASS >= input$pos_class_slider[1] & POS_CLASS <= (input$pos_class_slider[2] + 1)
               & ORGDATA_NUM_EMP >= input$emp_num[1] & ORGDATA_NUM_EMP <= input$emp_num[2]
               & AGE_NUM >= input$age_num[1] & AGE_NUM <= input$age_num[2]
        )
      }
    }  else if (input$job_stream_selector[1] == "4" & input$job_stream_selector[2] == "3" & input$job_stream_selector[3] == "2" & input$job_stream_selector[4] == "1" & length(input$job_stream_selector) == 4) {
      if(input$gender_selector == "Both") {
        subset(Master,
               (`Job Stream` == 4
                | `Job Stream` == 3
                | `Job Stream` == 2)
               & POS_CLASS >= input$pos_class_slider[1] & POS_CLASS <= (input$pos_class_slider[2] + 1)
               & ORGDATA_NUM_EMP >= input$emp_num[1] & ORGDATA_NUM_EMP <= input$emp_num[2]
               & AGE_NUM >= input$age_num[1] & AGE_NUM <= input$age_num[2]
        )
      } else if (input$gender_selector == "M") {
        subset(Master,
               (`Job Stream` == 4
                | `Job Stream` == 3
                | `Job Stream` == 2)
               & GENDER == "M"
               & POS_CLASS >= input$pos_class_slider[1] & POS_CLASS <= (input$pos_class_slider[2] + 1)
               & ORGDATA_NUM_EMP >= input$emp_num[1] & ORGDATA_NUM_EMP <= input$emp_num[2]
               & AGE_NUM >= input$age_num[1] & AGE_NUM <= input$age_num[2]
        )
      } else if (input$gender_selector == "F") {
        subset(Master,
               (`Job Stream` == 4
                | `Job Stream` == 3
                | `Job Stream` == 2)
               & GENDER == "F"
               & POS_CLASS >= input$pos_class_slider[1] & POS_CLASS <= (input$pos_class_slider[2] + 1)
               & ORGDATA_NUM_EMP >= input$emp_num[1] & ORGDATA_NUM_EMP <= input$emp_num[2]
               & AGE_NUM >= input$age_num[1] & AGE_NUM <= input$age_num[2]
        )
      } else {
        subset(Master,
               (`Job Stream` == 4
                | `Job Stream` == 3
                | `Job Stream` == 2)
               & POS_CLASS >= input$pos_class_slider[1] & POS_CLASS <= (input$pos_class_slider[2] + 1)
               & ORGDATA_NUM_EMP >= input$emp_num[1] & ORGDATA_NUM_EMP <= input$emp_num[2]
               & AGE_NUM >= input$age_num[1] & AGE_NUM <= input$age_num[2]
        )
      }
    }
    
  }) 
  
  output$pos_class_plot <- renderPlot({
    ggplot(data = dat(), aes(x = POS_CLASS, fill = GENDER)) + 
      geom_bar() +
      xlab("Position Class") +
      ylab("Count") +
      scale_fill_manual(values=c("#DF6E00", "#4D3D6A"))
  })
  
  output$comp1_plot <- renderPlot({
    ggplot(data= dat(), aes(COMP1, fill = GENDER)) +
      geom_histogram(breaks = seq(0,150000, by=5000), position=position_dodge()) + # position = "stack"
      xlab("Base Salary") +
      ylab("Count") +
      scale_x_continuous(breaks=0:150000*10000) +
      scale_fill_manual(values=c("#4D3D6A", "#DF6E00"))
  })
  
  output$subset_num <- renderText(   
    paste("Number of observations in subset: ", nrow(dat()))                                    
  )
  
  output$test <- renderText(length(input$job_stream_selector))

  
  
}

shinyApp(ui = ui, server = server)